**Description:**
laravel Based orders fillers project

**Admin Dashboard**
![Screenshot](dashboard.png)


Edit Order Form
![Screenshot](orders.png)


usdt, btc-adress

show rate



